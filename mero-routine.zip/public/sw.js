const SW_APP_VERSION = '1.0.0';
const CACHE_NAME = 'mero-routine-pwa-v2';
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/mero-routine-logo.svg',
  '/mero-routine-logo.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/apple-touch-icon.png',
  '/favicon-32x32.png',
  '/favicon-16x16.png',
  '/favicon.ico',
];

const ALARM_DB_NAME = 'mero-routine-alarms-v1';
const ALARM_DB_VERSION = 1;
const STORE_SCHEDULED = 'scheduled_alarms';
const STORE_FIRED = 'fired_alarms';
const STORE_META = 'alarm_meta';

let swNextAlarmTimeout = null;

function openAlarmIdb() {
  if (typeof indexedDB === 'undefined') {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(ALARM_DB_NAME, ALARM_DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_SCHEDULED)) {
          db.createObjectStore(STORE_SCHEDULED, { keyPath: 'dedupeKey' });
        }
        if (!db.objectStoreNames.contains(STORE_FIRED)) {
          db.createObjectStore(STORE_FIRED, { keyPath: 'dedupeKey' });
        }
        if (!db.objectStoreNames.contains(STORE_META)) {
          db.createObjectStore(STORE_META, { keyPath: 'key' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function getIdbScheduledAndFired() {
  const db = await openAlarmIdb();
  if (!db) {
    return { alarms: [], firedSet: new Set(), settings: null };
  }
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(
        [STORE_SCHEDULED, STORE_FIRED, STORE_META],
        'readonly'
      );
      const schedReq = tx.objectStore(STORE_SCHEDULED).getAll();
      const firedReq = tx.objectStore(STORE_FIRED).getAll();
      const metaReq = tx.objectStore(STORE_META).get('userSettings');

      tx.oncomplete = () => {
        const alarms = Array.isArray(schedReq.result) ? schedReq.result : [];
        const firedArr = Array.isArray(firedReq.result) ? firedReq.result : [];
        const firedSet = new Set(
          firedArr.map((r) => r && r.dedupeKey).filter(Boolean)
        );
        const settings = metaReq.result ? metaReq.result.value : null;
        resolve({ alarms, firedSet, settings });
      };
      tx.onerror = () =>
        resolve({ alarms: [], firedSet: new Set(), settings: null });
    } catch {
      resolve({ alarms: [], firedSet: new Set(), settings: null });
    }
  });
}

async function markFiredInIdb(dedupeKey) {
  const db = await openAlarmIdb();
  if (!db) return false;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_FIRED, 'readwrite');
      const store = tx.objectStore(STORE_FIRED);
      const getReq = store.get(dedupeKey);
      getReq.onsuccess = () => {
        if (getReq.result) {
          resolve(false);
        } else {
          store.put({ dedupeKey, firedAtMs: Date.now() });
          resolve(true);
        }
      };
      getReq.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

async function broadcastToClients(msg) {
  try {
    const clients = await self.clients.matchAll({
      type: 'window',
      includeUncontrolled: true,
    });
    for (const client of clients) {
      try {
        client.postMessage(msg);
      } catch {
        // Ignore individual client postMessage error
      }
    }
    return clients.length;
  } catch {
    return 0;
  }
}

async function fireSwAlarmNotification(alarm, isTest = false) {
  if (!alarm || !alarm.dedupeKey) return false;

  const newlyMarked = await markFiredInIdb(alarm.dedupeKey);
  if (!newlyMarked) {
    return false;
  }

  const title = alarm.title || `🔔 ${alarm.routineTitle || 'Mero Routine'}`;
  const body =
    alarm.body ||
    `Time for ${alarm.routineTitle || 'your scheduled routine'} (${
      alarm.routineTime || ''
    }).`;

  const notifData = {
    dedupeKey: alarm.dedupeKey,
    routineId: alarm.routineId || 'sample',
    dateStr: alarm.dateStr || '',
    routineTitle: alarm.routineTitle || 'Routine Reminder',
    routineTime: alarm.routineTime || '06:00',
    routineIcon: alarm.routineIcon || '🔔',
    body,
    soundId: alarm.soundId || 'default_1',
    defaultSoundId: alarm.defaultSoundId || 'default_1',
    isTest: Boolean(isTest),
  };

  try {
    await self.registration.showNotification(title, {
      body,
      icon: '/pwa-192x192.png',
      badge: '/favicon-32x32.png',
      tag: alarm.dedupeKey,
      renotify: Boolean(isTest),
      requireInteraction: true,
      vibrate: [300, 150, 300, 150, 400],
      data: notifData,
      actions: [
        { action: 'done', title: '✓ Mark Done' },
        { action: 'snooze', title: '⏰ Snooze 10m' },
      ],
    });
  } catch {
    // Fallback minimal notification options if browser rejects actions/vibrate
    try {
      await self.registration.showNotification(title, {
        body,
        icon: '/pwa-192x192.png',
        tag: alarm.dedupeKey,
        data: notifData,
      });
    } catch {
      // Ignore
    }
  }

  await broadcastToClients({
    type: 'SW_ALARM_FIRED',
    alarm: notifData,
  });

  return true;
}

async function scheduleOsNotificationTriggersIfSupported(alarms, firedSet) {
  try {
    if (
      typeof self.TimestampTrigger !== 'function' ||
      typeof Notification === 'undefined' ||
      !('showTrigger' in Notification.prototype)
    ) {
      return;
    }
    const nowMs = Date.now();
    const horizonMs = nowMs + 24 * 60 * 60 * 1000;
    for (const alarm of alarms) {
      if (
        !alarm ||
        !alarm.dedupeKey ||
        firedSet.has(alarm.dedupeKey) ||
        alarm.triggerTimestampMs <= nowMs ||
        alarm.triggerTimestampMs > horizonMs
      ) {
        continue;
      }
      await self.registration.showNotification(
        alarm.title || `🔔 ${alarm.routineTitle} — Mero Routine`,
        {
          body: alarm.body,
          icon: '/pwa-192x192.png',
          badge: '/favicon-32x32.png',
          tag: alarm.dedupeKey,
          requireInteraction: true,
          vibrate: [300, 150, 300, 150, 400],
          showTrigger: new self.TimestampTrigger(alarm.triggerTimestampMs),
          data: {
            dedupeKey: alarm.dedupeKey,
            routineId: alarm.routineId,
            dateStr: alarm.dateStr,
            routineTitle: alarm.routineTitle,
            routineTime: alarm.routineTime,
            routineIcon: alarm.routineIcon || '🔔',
            body: alarm.body,
          },
        }
      );
    }
  } catch {
    // Ignore if TimestampTrigger is not enabled on this browser
  }
}

async function checkAndScheduleSwAlarms() {
  if (swNextAlarmTimeout) {
    clearTimeout(swNextAlarmTimeout);
    swNextAlarmTimeout = null;
  }

  const { alarms, firedSet, settings } = await getIdbScheduledAndFired();
  if (settings && settings.notificationsEnabled === false) {
    return;
  }

  const nowMs = Date.now();
  const GRACE_WINDOW_MS = 30 * 60 * 1000; // 30 minutes catch-up window
  let earliestFutureMs = Infinity;

  for (const alarm of alarms) {
    if (!alarm || !alarm.dedupeKey || firedSet.has(alarm.dedupeKey)) {
      continue;
    }
    const triggerMs = Number(alarm.triggerTimestampMs) || 0;
    if (!triggerMs) continue;

    if (triggerMs <= nowMs && nowMs - triggerMs <= GRACE_WINDOW_MS) {
      await fireSwAlarmNotification(alarm, false);
      firedSet.add(alarm.dedupeKey);
    } else if (triggerMs > nowMs && triggerMs < earliestFutureMs) {
      earliestFutureMs = triggerMs;
    }
  }

  await scheduleOsNotificationTriggersIfSupported(alarms, firedSet);

  if (earliestFutureMs < Infinity) {
    const delayMs = Math.min(
      2147483647,
      Math.max(250, earliestFutureMs - Date.now() + 50)
    );
    swNextAlarmTimeout = setTimeout(() => {
      checkAndScheduleSwAlarms().catch(() => {});
    }, delayMs);
  }
}

self.addEventListener('install', (event) => {
  const hasActiveWorker = Boolean(self.registration && self.registration.active);

  if (!hasActiveWorker) {
    self.skipWaiting();
  }

  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) =>
        Promise.allSettled(
          PRECACHE_ASSETS.map((assetUrl) => cache.add(assetUrl))
        )
      )
      .then(async () => {
        if (hasActiveWorker) {
          await broadcastToClients({
            type: 'SW_UPDATE_AVAILABLE',
            version: SW_APP_VERSION,
          });
        }
      })
      .catch(() => {})
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter(
              (key) => key.startsWith('mero-routine-pwa-') && key !== CACHE_NAME
            )
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
      .then(() => checkAndScheduleSwAlarms())
      .then(() =>
        broadcastToClients({
          type: 'SW_ACTIVATED',
          version: SW_APP_VERSION,
        })
      )
      .catch(() => {})
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Never intercept API routes, Vite HMR/dev requests, or external Firebase/Google APIs
  // so routes and user data always stay live and up to date
  if (
    url.origin !== self.location.origin ||
    url.pathname.startsWith('/api/') ||
    url.pathname.startsWith('/uploads/') ||
    url.pathname.startsWith('/@') ||
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches
            .open(CACHE_NAME)
            .then((cache) => cache.put('/', copy))
            .catch(() => {});
          return response;
        })
        .catch(async () => {
          const cached =
            (await caches.match(request)) ||
            (await caches.match('/')) ||
            (await caches.match('/index.html'));
          return cached || Response.error();
        })
    );
    return;
  }

  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response && response.status === 200 && response.type === 'basic') {
          const copy = response.clone();
          caches
            .open(CACHE_NAME)
            .then((cache) => cache.put(request, copy))
            .catch(() => {});
        }
        return response;
      })
      .catch(async () => {
        const cached = await caches.match(request);
        return cached || Response.error();
      })
  );
});

self.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'SYNC_ALARMS') {
    event.waitUntil(
      (async () => {
        const payload = data.payload || {};
        const db = await openAlarmIdb();
        if (db) {
          await new Promise((resolve) => {
            try {
              const tx = db.transaction(
                [STORE_SCHEDULED, STORE_META, STORE_FIRED],
                'readwrite'
              );
              const schedStore = tx.objectStore(STORE_SCHEDULED);
              schedStore.clear();
              if (Array.isArray(payload.alarms)) {
                for (const item of payload.alarms) {
                  if (item && item.dedupeKey) {
                    schedStore.put(item);
                  }
                }
              }
              if (payload.settings) {
                tx.objectStore(STORE_META).put({
                  key: 'userSettings',
                  value: payload.settings,
                });
              }
              if (Array.isArray(payload.firedKeys)) {
                const firedStore = tx.objectStore(STORE_FIRED);
                for (const k of payload.firedKeys) {
                  if (typeof k === 'string') {
                    firedStore.put({ dedupeKey: k, firedAtMs: Date.now() });
                  }
                }
              }
              tx.oncomplete = () => resolve();
              tx.onerror = () => resolve();
            } catch {
              resolve();
            }
          });
        }
        await checkAndScheduleSwAlarms();
      })()
    );
    return;
  }

  if (data.type === 'CHECK_ALARMS_NOW') {
    event.waitUntil(checkAndScheduleSwAlarms());
    return;
  }

  if (data.type === 'MARK_ALARM_FIRED' && data.dedupeKey) {
    event.waitUntil(markFiredInIdb(data.dedupeKey));
    return;
  }

  if (data.type === 'SCHEDULE_DELAYED_ALARM' && data.alarm) {
    const delayMs = Math.max(0, Math.min(60000, Number(data.delayMs) || 0));
    event.waitUntil(
      new Promise((resolve) => {
        setTimeout(async () => {
          await fireSwAlarmNotification(data.alarm, Boolean(data.isTest));
          resolve();
        }, delayMs);
      })
    );
    return;
  }

  if (data.type === 'SKIP_WAITING' || data.type === 'APPLY_SW_UPDATE') {
    event.waitUntil(
      (async () => {
        try {
          const keys = await caches.keys();
          await Promise.all(
            keys
              .filter(
                (key) =>
                  key.startsWith('mero-routine-pwa-') && key !== CACHE_NAME
              )
              .map((key) => caches.delete(key))
          );
        } catch {
          // Ignore cache cleanup errors
        }
        try {
          await self.skipWaiting();
        } catch {
          // Ignore skipWaiting errors
        }
      })()
    );
    return;
  }

  if (data.type === 'GET_SW_VERSION') {
    event.waitUntil(
      broadcastToClients({
        type: 'SW_VERSION_INFO',
        version: SW_APP_VERSION,
        cacheName: CACHE_NAME,
      })
    );
    return;
  }

  if (data.type === 'DISMISS_NOTIFICATION' && data.key) {
    event.waitUntil(
      self.registration
        .getNotifications()
        .then((notifs) => {
          for (const n of notifs) {
            if (
              n.tag === data.key ||
              (n.data && n.data.routineId === data.key)
            ) {
              n.close();
            }
          }
        })
        .catch(() => {})
    );
  }
});

self.addEventListener('push', (event) => {
  event.waitUntil(
    (async () => {
      let payload = null;
      try {
        if (event.data) {
          payload = event.data.json();
        }
      } catch {
        try {
          payload = {
            title: '🔔 Mero Routine Reminder',
            body: event.data ? event.data.text() : 'Scheduled routine reminder',
            dedupeKey: `push_${Date.now()}`,
          };
        } catch {
          payload = null;
        }
      }

      if (!payload) {
        await checkAndScheduleSwAlarms();
        return;
      }

      await fireSwAlarmNotification(payload, Boolean(payload.isTest));
    })()
  );
});

self.addEventListener('sync', (event) => {
  if (event.tag === 'mero-routine-alarm-sync') {
    event.waitUntil(checkAndScheduleSwAlarms());
  }
});

self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'mero-routine-alarm-check') {
    event.waitUntil(checkAndScheduleSwAlarms());
  }
});

self.addEventListener('notificationclick', (event) => {
  const notif = event.notification;
  const notifData = (notif && notif.data) || {};
  const action = event.action || 'open';
  notif.close();

  event.waitUntil(
    (async () => {
      // If user clicked "✓ Mark Done" or "⏰ Snooze 10m" directly on the notification
      if (
        (action === 'done' || action === 'snooze') &&
        notifData.routineId &&
        notifData.routineId !== 'sample' &&
        notifData.routineId !== 'test_alarm'
      ) {
        const { settings } = await getIdbScheduledAndFired();
        const authToken = settings && settings.authToken;
        if (authToken) {
          const now = new Date();
          const totalMins = now.getHours() * 60 + now.getMinutes() + 10;
          const snoozedH = String(Math.floor((totalMins % 1440) / 60)).padStart(
            2,
            '0'
          );
          const snoozedM = String(totalMins % 60).padStart(2, '0');
          const snoozedUntil =
            action === 'snooze' ? `${snoozedH}:${snoozedM}` : '';

          try {
            await fetch('/api/routine-logs', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${authToken}`,
              },
              body: JSON.stringify({
                routineId: notifData.routineId,
                date: notifData.dateStr || '',
                status: action === 'done' ? 'done' : 'snoozed',
                snoozedUntil,
              }),
            });
          } catch {
            // Ignore network error when offline
          }
        }

        const clientCount = await broadcastToClients({
          type: 'SW_NOTIFICATION_ACTION',
          action: action === 'done' ? 'done' : 'snooze',
          alarm: notifData,
        });
        if (clientCount > 0) {
          return;
        }
      }

      const clientList = await self.clients.matchAll({
        type: 'window',
        includeUncontrolled: true,
      });

      for (const client of clientList) {
        if ('focus' in client) {
          await client.focus();
          client.postMessage({
            type: 'SW_NOTIFICATION_CLICKED',
            action,
            alarm: notifData,
          });
          return;
        }
      }

      if (self.clients.openWindow) {
        const query = notifData.routineId
          ? `/?alarmRoutineId=${encodeURIComponent(
              notifData.routineId
            )}&alarmDate=${encodeURIComponent(
              notifData.dateStr || ''
            )}&alarmKey=${encodeURIComponent(notifData.dedupeKey || '')}`
          : '/';
        return self.clients.openWindow(query);
      }
    })()
  );
});
